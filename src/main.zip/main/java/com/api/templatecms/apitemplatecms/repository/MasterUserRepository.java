package com.api.templatecms.apitemplatecms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.api.templatecms.apitemplatecms.model.MasterUser;

@Repository
public interface MasterUserRepository extends JpaRepository<MasterUser, Long> {
    
}
