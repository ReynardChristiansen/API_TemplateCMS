package com.api.templatecms.apitemplatecms.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

// import jakarta.persistence.Table;

@Entity
@Table(name = "Master_Users") // Nama tabel di database
public class MasterUser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Sesuaikan strategi ID
    private Long id;

    private LocalDateTime createddate;
    private String createdby;
    private LocalDateTime updateddate;
    private String updatedby;
    private String userLogin;
    private String userPass;
    private String nama;
    private boolean isLDAP; // Sesuaikan tipe data
    private String sts; // Sesuaikan tipe data
    private int countFailedLogin; // Sesuaikan tipe data
    private boolean isLogin;
    private LocalDateTime lastActive;

    // Constructor tanpa argumen
    public MasterUser() {}

    // Getter dan Setter untuk semua field

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getCreateddate() {
        return createddate;
    }

    public void setCreateddate(LocalDateTime createddate) {
        this.createddate = createddate;
    }

    public String getCreatedby() {
        return createdby;
    }

    public void setCreatedby(String createdby) {
        this.createdby = createdby;
    }

    public LocalDateTime getUpdateddate() {
        return updateddate;
    }

    public void setUpdateddate(LocalDateTime updateddate) {
        this.updateddate = updateddate;
    }

    public String getUpdatedby() {
        return updatedby;
    }

    public void setUpdatedby(String updatedby) {
        this.updatedby = updatedby;
    }

    public String getUserLogin() {
        return userLogin;
    }

    public void setUserLogin(String userLogin) {
        this.userLogin = userLogin;
    }

    public String getUserPass() {
        return userPass;
    }

    public void setUserPass(String userPass) {
        this.userPass = userPass;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public boolean isLDAP() {
        return isLDAP;
    }

    public void setLDAP(boolean isLDAP) {
        this.isLDAP = isLDAP;
    }

    public String getSts() {
        return sts;
    }

    public void setSts(String sts) {
        this.sts = sts;
    }

    public int getCountFailedLogin() {
        return countFailedLogin;
    }

    public void setCountFailedLogin(int countFailedLogin) {
        this.countFailedLogin = countFailedLogin;
    }

    public boolean isLogin() {
        return isLogin;
    }

    public void setLogin(boolean isLogin) {
        this.isLogin = isLogin;
    }

    public LocalDateTime getLastActive() {
        return lastActive;
    }

    public void setLastActive(LocalDateTime lastActive) {
        this.lastActive = lastActive;
    }
}
