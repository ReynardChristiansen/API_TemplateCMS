package com.api.templatecms.apitemplatecms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApitemplatecmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApitemplatecmsApplication.class, args);
	}

}
